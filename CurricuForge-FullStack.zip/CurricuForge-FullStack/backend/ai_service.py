import os
import logging
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

class AIService:
    """AI service that handles different providers"""
    
    def __init__(self):
        self.provider = os.getenv('AI_PROVIDER', 'demo').lower()
        self.api_key = os.getenv('OPENAI_API_KEY')
        self.gemini_key = os.getenv('GEMINI_API_KEY')
        
        logger.info(f"Initializing AI service with provider: {self.provider}")
        
        # Initialize the appropriate AI client
        if self.provider == 'openai' and self.api_key and self.api_key != 'your-openai-api-key-here':
            self._init_openai()
        elif self.provider == 'gemini' and self.gemini_key and self.gemini_key != 'your-gemini-api-key-here':
            self._init_gemini()
        else:
            logger.info("Using demo mode (no API calls)")
            self.provider = 'demo'
    
    def _init_openai(self):
        """Initialize OpenAI client"""
        try:
            import openai
            openai.api_key = self.api_key
            self.client = openai.OpenAI(api_key=self.api_key)
            logger.info("OpenAI initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI: {e}")
            self.provider = 'demo'
    
    def _init_gemini(self):
        """Initialize Google Gemini client"""
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.gemini_key)
            self.model = genai.GenerativeModel('gemini-pro')
            logger.info("Gemini initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Gemini: {e}")
            self.provider = 'demo'
    
    def generate_curriculum(self, data):
        """Generate curriculum based on provider"""
        
        if self.provider == 'openai':
            return self._generate_openai(data)
        elif self.provider == 'gemini':
            return self._generate_gemini(data)
        else:
            return self._generate_demo(data)
    
    def _generate_openai(self, data):
        """Generate using OpenAI"""
        try:
            prompt = self._create_prompt(data)
            
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert curriculum designer. Create detailed, structured learning paths."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=1500
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"OpenAI generation error: {e}")
            # Fallback to demo
            return self._generate_demo(data)
    
    def _generate_gemini(self, data):
        """Generate using Google Gemini"""
        try:
            prompt = self._create_prompt(data)
            
            response = self.model.generate_content(prompt)
            return response.text
            
        except Exception as e:
            logger.error(f"Gemini generation error: {e}")
            return self._generate_demo(data)
    
    def _generate_demo(self, data):
        """Generate demo curriculum (no API calls)"""
        course = data.get('course', 'Your Course')
        level = data.get('level', 'Beginner')
        duration = data.get('duration', '3 months')
        goal = data.get('goal', 'Master the subject')
        
        return f"""
        <h3>📚 {course} - {level} Level Learning Path</h3>
        <p><strong>Duration:</strong> {duration} | <strong>Goal:</strong> {goal}</p>
        
        <div class="week-card">
            <h4>📖 Week 1-2: Getting Started</h4>
            <ul>
                <li><strong>Topics:</strong> Introduction to {course}, core concepts, basic terminology</li>
                <li><strong>Resources:</strong> 
                    <ul>
                        <li>📹 "Introduction to {course}" (YouTube)</li>
                        <li>📄 Official documentation</li>
                        <li>💻 Interactive tutorials</li>
                    </ul>
                </li>
                <li><strong>Practice:</strong> Complete 5 basic exercises</li>
                <li><strong>Project:</strong> Build a simple "Hello World" application</li>
            </ul>
        </div>
        
        <div class="week-card">
            <h4>⚡ Week 3-4: Building Skills</h4>
            <ul>
                <li><strong>Topics:</strong> Intermediate concepts, practical applications, common patterns</li>
                <li><strong>Resources:</strong>
                    <ul>
                        <li>📚 "Learning {course}" book (Chapters 3-5)</li>
                        <li>📹 Advanced tutorials</li>
                        <li>👥 Join community discussions</li>
                    </ul>
                </li>
                <li><strong>Practice:</strong> Solve 10 intermediate problems</li>
                <li><strong>Project:</strong> Build a mini-application</li>
            </ul>
        </div>
        
        <div class="week-card">
            <h4>🚀 Week 5-6: Advanced Topics</h4>
            <ul>
                <li><strong>Topics:</strong> Advanced techniques, optimization, best practices</li>
                <li><strong>Resources:</strong>
                    <ul>
                        <li>📹 Advanced course on Coursera/Udemy</li>
                        <li>📄 Research papers and blogs</li>
                        <li>💻 Open source contributions</li>
                    </ul>
                </li>
                <li><strong>Practice:</strong> Complex problem-solving</li>
                <li><strong>Project:</strong> Build a real-world application</li>
            </ul>
        </div>
        
        <div class="week-card">
            <h4>🎯 Week 7-8: Mastery & Portfolio</h4>
            <ul>
                <li><strong>Topics:</strong> Capstone project, documentation, presentation</li>
                <li><strong>Resources:</strong>
                    <ul>
                        <li>👥 Peer review and feedback</li>
                        <li>📹 Project presentation tips</li>
                        <li>💼 Portfolio building guides</li>
                    </ul>
                </li>
                <li><strong>Project:</strong> Complete and polish your portfolio project</li>
                <li><strong>Next Steps:</strong> Specialization recommendations</li>
            </ul>
        </div>
        
        <h4>📚 Recommended Learning Resources:</h4>
        <ul>
            <li><strong>Video Courses:</strong>
                <ul>
                    <li>🎥 "{course} for Beginners" - freeCodeCamp (YouTube)</li>
                    <li>🎥 "{course} Masterclass" - Udemy/Coursera</li>
                </ul>
            </li>
            <li><strong>Books:</strong>
                <ul>
                    <li>📘 "The Complete Guide to {course}"</li>
                    <li>📗 "{course} Design Patterns"</li>
                </ul>
            </li>
            <li><strong>Practice Platforms:</strong>
                <ul>
                    <li>💻 LeetCode / HackerRank</li>
                    <li>🐱 GitHub - Open source projects</li>
                </ul>
            </li>
            <li><strong>Communities:</strong>
                <ul>
                    <li>👥 Reddit - r/{course.lower()}</li>
                    <li>💬 Discord/Slack communities</li>
                </ul>
            </li>
        </ul>
        
        <h4>✅ Milestones to Track:</h4>
        <ul>
            <li>✓ Complete first project</li>
            <li>✓ Join a community and ask questions</li>
            <li>✓ Contribute to open source</li>
            <li>✓ Build portfolio with 3 projects</li>
            <li>✓ Network with professionals</li>
        </ul>
        """
    
    def _create_prompt(self, data):
        """Create AI prompt from user data"""
        return f"""Create a detailed learning curriculum for:

Course: {data.get('course')}
Level: {data.get('level')}
Duration: {data.get('duration')}
Goal: {data.get('goal')}
Learning Style: {data.get('style', 'Mixed')}

Please provide:
1. Week-by-week breakdown with specific topics
2. Learning resources (videos, articles, books)
3. Practical exercises and projects
4. Milestones to track progress
5. Assessment methods

Make it practical and achievable."""