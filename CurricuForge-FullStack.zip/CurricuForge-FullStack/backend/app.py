from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
import os
import logging
import time
from ai_service import AIService

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Initialize AI Service
ai_service = AIService()

# Request logging middleware
@app.before_request
def log_request():
    logger.info(f"Request: {request.method} {request.path}")

# Health check endpoint
@app.route('/api/v1/health', methods=['GET'])
def health_check():
    """Check if API is running"""
    return jsonify({
        'status': 'healthy',
        'provider': os.getenv('AI_PROVIDER', 'demo'),
        'timestamp': time.time()
    })

# Generate curriculum endpoint
@app.route('/api/v1/generate', methods=['POST'])
def generate_curriculum():
    """Generate curriculum based on user input"""
    
    # Get request data
    data = request.get_json()
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    # Validate required fields
    required_fields = ['course', 'level', 'duration', 'goal']
    for field in required_fields:
        if field not in data:
            return jsonify({'error': f'Missing required field: {field}'}), 400
    
    try:
        # Generate curriculum
        curriculum = ai_service.generate_curriculum(data)
        
        return jsonify({
            'success': True,
            'data': curriculum,
            'provider': ai_service.provider
        })
        
    except Exception as e:
        logger.error(f"Error generating curriculum: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Demo endpoint (no AI required)
@app.route('/api/v1/demo', methods=['POST'])
def demo_curriculum():
    """Generate demo curriculum (for testing without AI)"""
    
    data = request.get_json()
    
    # Generate demo curriculum
    demo_curriculum = f"""
    <h3>📚 {data.get('course')} - {data.get('level')} Level Learning Path</h3>
    <p><strong>Duration:</strong> {data.get('duration')}</p>
    <p><strong>Goal:</strong> {data.get('goal')}</p>
    
    <div class="week-card">
        <h4>📖 Week 1-2: Foundations</h4>
        <ul>
            <li>Introduction to core concepts</li>
            <li>Setting up your environment</li>
            <li>Basic principles and terminology</li>
            <li><strong>Resource:</strong> "Getting Started" tutorials</li>
            <li><strong>Practice:</strong> Simple exercises</li>
        </ul>
    </div>
    
    <div class="week-card">
        <h4>⚡ Week 3-4: Core Skills</h4>
        <ul>
            <li>Essential techniques and methods</li>
            <li>Hands-on practice sessions</li>
            <li>Real-world applications</li>
            <li><strong>Resource:</strong> Interactive tutorials</li>
            <li><strong>Project:</strong> Build a small application</li>
        </ul>
    </div>
    
    <div class="week-card">
        <h4>🚀 Week 5-6: Advanced Topics</h4>
        <ul>
            <li>Advanced concepts and best practices</li>
            <li>Performance optimization</li>
            <li>Industry standards</li>
            <li><strong>Resource:</strong> Advanced courses</li>
            <li><strong>Project:</strong> Portfolio project</li>
        </ul>
    </div>
    
    <div class="week-card">
        <h4>🎯 Week 7-8: Mastery</h4>
        <ul>
            <li>Capstone project</li>
            <li>Code review and refinement</li>
            <li>Documentation and presentation</li>
            <li><strong>Resource:</strong> Community feedback</li>
            <li><strong>Next Steps:</strong> Advanced specialization</li>
        </ul>
    </div>
    
    <h4>📌 Recommended Resources:</h4>
    <ul>
        <li>📹 Video Courses: YouTube, Coursera, Udemy</li>
        <li>📚 Books: "The Complete Guide" series</li>
        <li>💻 Practice: Coding platforms, GitHub</li>
        <li>👥 Community: Forums, Discord, Meetups</li>
    </ul>
    """
    
    return jsonify({
        'success': True,
        'data': demo_curriculum,
        'provider': 'demo'
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal server error: {error}")
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_ENV') == 'development'
    
    logger.info(f"Starting CurricuForge backend on {host}:{port}")
    app.run(host=host, port=port, debug=debug)