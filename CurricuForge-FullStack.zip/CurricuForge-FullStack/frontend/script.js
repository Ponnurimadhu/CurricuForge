// Configuration
const API_BASE_URL = 'http://localhost:5000/api/v1'; // Change this to your backend URL

// DOM Elements
const form = document.getElementById('curriculumForm');
const courseInput = document.getElementById('course');
const levelSelect = document.getElementById('level');
const durationInput = document.getElementById('duration');
const goalInput = document.getElementById('goal');
const styleInput = document.getElementById('style');
const styleOptions = document.querySelectorAll('.style-option');
const submitBtn = document.getElementById('submitBtn');
const loadingDiv = document.getElementById('loading');
const resultDiv = document.getElementById('result');
const curriculumContent = document.getElementById('curriculumContent');
const copyBtn = document.getElementById('copyBtn');
const toast = document.getElementById('toast');
const toastMessage = document.getElementById('toastMessage');

// Style selection
styleOptions.forEach(option => {
    option.addEventListener('click', () => {
        styleOptions.forEach(opt => opt.classList.remove('active'));
        option.classList.add('active');
        styleInput.value = option.dataset.style;
    });
});

// Form submission
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Validate form
    if (!validateForm()) {
        return;
    }
    
    // Prepare data
    const formData = {
        course: courseInput.value,
        level: levelSelect.value,
        duration: durationInput.value,
        goal: goalInput.value,
        style: styleInput.value
    };
    
    // Show loading, hide previous results
    loadingDiv.classList.remove('hidden');
    resultDiv.classList.add('hidden');
    submitBtn.disabled = true;
    
    try {
        // Send to backend
        const curriculum = await generateCurriculum(formData);
        
        // Display result
        displayCurriculum(curriculum);
        showToast('Curriculum generated successfully!', 'success');
    } catch (error) {
        console.error('Error:', error);
        showToast(error.message || 'Failed to generate curriculum', 'error');
    } finally {
        loadingDiv.classList.add('hidden');
        submitBtn.disabled = false;
    }
});

// Validate form
function validateForm() {
    if (!courseInput.value.trim()) {
        showToast('Please enter a course name', 'error');
        courseInput.focus();
        return false;
    }
    
    if (!levelSelect.value) {
        showToast('Please select your level', 'error');
        levelSelect.focus();
        return false;
    }
    
    if (!durationInput.value.trim()) {
        showToast('Please enter duration', 'error');
        durationInput.focus();
        return false;
    }
    
    if (!goalInput.value.trim()) {
        showToast('Please enter your goal', 'error');
        goalInput.focus();
        return false;
    }
    
    return true;
}

// Generate curriculum via backend API
async function generateCurriculum(formData) {
    try {
        const response = await fetch(`${API_BASE_URL}/generate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to generate curriculum');
        }
        
        return data.data;
    } catch (error) {
        console.error('API Error:', error);
        throw new Error('Failed to connect to server. Make sure the backend is running.');
    }
}

// Display curriculum
function displayCurriculum(curriculum) {
    // If curriculum is a string (HTML), use it directly
    if (typeof curriculum === 'string') {
        curriculumContent.innerHTML = curriculum;
    } 
    // If it's an object, format it
    else if (typeof curriculum === 'object') {
        let html = '';
        
        // Format weeks
        if (curriculum.weeks) {
            curriculum.weeks.forEach(week => {
                html += `
                    <div class="week-card">
                        <h4>${week.title}</h4>
                        <ul>
                            ${week.topics.map(topic => `<li>${topic}</li>`).join('')}
                        </ul>
                    </div>
                `;
            });
        }
        
        // Format resources
        if (curriculum.resources) {
            html += '<h3>📚 Resources</h3><ul>';
            curriculum.resources.forEach(resource => {
                html += `<li>${resource}</li>`;
            });
            html += '</ul>';
        }
        
        curriculumContent.innerHTML = html;
    }
    
    resultDiv.classList.remove('hidden');
    
    // Scroll to result
    resultDiv.scrollIntoView({ behavior: 'smooth' });
}

// Copy to clipboard
copyBtn.addEventListener('click', () => {
    const content = curriculumContent.innerText;
    navigator.clipboard.writeText(content).then(() => {
        showToast('Copied to clipboard!', 'success');
    }).catch(() => {
        showToast('Failed to copy', 'error');
    });
});

// Show toast notification
function showToast(message, type = 'info') {
    toastMessage.textContent = message;
    
    // Set icon color based on type
    const icon = toast.querySelector('i');
    if (type === 'success') {
        icon.className = 'fas fa-check-circle';
        icon.style.color = '#4CAF50';
    } else if (type === 'error') {
        icon.className = 'fas fa-exclamation-circle';
        icon.style.color = '#f44336';
    } else {
        icon.className = 'fas fa-info-circle';
        icon.style.color = '#764ba2';
    }
    
    toast.classList.remove('hidden');
    
    // Auto hide after 3 seconds
    setTimeout(() => {
        toast.classList.add('hidden');
    }, 3000);
}

// Check if backend is available on load
async function checkBackend() {
    try {
        const response = await fetch(`${API_BASE_URL}/health`);
        if (response.ok) {
            console.log('✅ Backend is connected');
        } else {
            console.warn('⚠️ Backend returned error');
        }
    } catch (error) {
        console.warn('⚠️ Backend is not running. Start the Flask server.');
        showToast('Backend server not running. Start it first!', 'error');
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    checkBackend();
});